//
// Created by hanse on 2023-02-26.
//

#ifndef MY_APPLICATION3_LIBHELLO_TEST_H
#define MY_APPLICATION3_LIBHELLO_TEST_H
extern "C" __attribute__((visibility("default"))) void *alloc_memory(size_t sz);

#endif //MY_APPLICATION3_LIBHELLO_TEST_H
