#include <jni.h>
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include "libhello-test.h"
#include <sys/mman.h>


// Find the load address of the shared library

extern "C" __attribute__((visibility("default"))) JNIEXPORT jstring JNICALL
Java_com_example_myapplication3_MainActivity_sumFromCustomJNI(
        JNIEnv* env,
        jobject /* this */) {

    char *str=(char*)malloc(260);
    int fd;
    int param=42;
    void *(*alloc_memory_func_ptr)(size_t);
    alloc_memory_func_ptr=&alloc_memory;
    char hello[20];
    sprintf(hello,"%p",alloc_memory_func_ptr);
    char target[128];

    memset(target,NULL,128);
    fd=open("/data/data/com.example.myapplication3/files/payload.txt",O_RDONLY);
    if(fd>0) {
        read(fd,str,260);
        strcat(target,str);
        close(fd);
    }
    else {
        sprintf(target,"File Open Fail...\n");
    }

    void *p =(alloc_memory_func_ptr)(param);
    void *q =(alloc_memory_func_ptr)(param);
    free(p);
    free(q);
    std::string myString(hello);
    return env->NewStringUTF(myString.c_str());
}
